import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import App from "./App";
import reportWebVitals from "./reportWebVitals";
const trailRoot = document.getElementById("root");
if (trailRoot) {
  trailRoot.attachShadow({ mode: "open" });
  const shadowRoot = trailRoot.shadowRoot;
  if (shadowRoot) {
    ReactDOM.render(<App />, shadowRoot);
  }
}

reportWebVitals();
