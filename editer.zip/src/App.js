import logo from './logo.svg';
import './App.css';
import { CKEditor } from '@ckeditor/ckeditor5-react'
import CustomEditor from 'ckeditor5-custom-build/build/ckeditor'

function App() {

  return (
    <div className="App">
      <header className="App-header">
        <CKEditor
          editor={CustomEditor}
          config={{
            toolbar: [
              'undo',
              'redo',
              '|',
              'bold',
              'italic',
              'underline',
            ],
            link: {
              defaultProtocol: '//'
            },
          }}
          data={"<p>Hello from CKEditor my!</p>"}
        />
      </header>
    </div>
  );
}

export default App;
