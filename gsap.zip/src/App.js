import React, { useEffect, useRef, useState } from 'react';
import { Tween } from 'react-gsap';
import './style.css';

export default function App() {
  const [ele, setEle] = useState(null)
  const eleRef = useRef(null)
  console.log(ele?.y, ele?.y + ele?.height);
  useEffect(() => {
    setEle(eleRef.current.getBoundingClientRect());
  }, []);
  return (
    <>
      <section>
        <h1>Hello StackBlitz!</h1>
      </section>
      <section className="section2">
        <h1>Hello StackBlitz!</h1>
      </section>
      <section ref={eleRef}>
        <div className="borderBg">
          {ele &&
            <Tween
              to={{
                height: '100%',
                scrollTrigger: {
                  trigger: '#sec3',
                  start: `${ele?.y}px center`,
                  end: `${ele?.y + ele?.height}px center`,
                  scrub: 0.5,
                  // markers: true,
                },
              }}
            >
              <div className="border"></div>
            </Tween>}
        </div>
        <h1>Hello StackBlitz!</h1>
      </section>
      <section className="section2">
        <h1>Hello StackBlitz!</h1>
      </section>
    </>
  );
}
