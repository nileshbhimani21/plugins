import React, { useState } from 'react';
import Pagination from './pagination';
import './App.css';

export default function App() {
  const [state, setState] = useState({
    page: 1,
    recordsPerPage: 10,
    enterpageno: ''
  })
  const onChangeRecordsPerPage = (event) => {
    setState({ ...state, recordsPerPage: parseInt(event.target.value) })
  }
  const gotoPage = () => {
    if (!isNaN(parseInt(state.enterpageno))) {
      setState({ ...state, page: parseInt(state.enterpageno) })
    }
  }

  const onPageChanged = (page) => {
    setState({ ...state, page: page })
  }

  const inputPageChange = (e) => {
    if (!isNaN(parseInt(e.target.value))) {
      setState({ ...state, enterpageno: parseInt(e.target.value) })
    }
  }
  return <div className="App">
    <ul className="showItems">
      <li>Rows <select onChange={(e) => onChangeRecordsPerPage(e)}>
          <option value="10">10</option>
          <option value="20">20</option>
          <option value="30">30</option>
          <option value="40">40</option>
          <option value="50">50</option>
        </select>
      </li>
      <li>
        Go to Page <input type="text" value={state.enterpageno} onChange={(e) => { inputPageChange(e) }} /><button type="button" onClick={() => gotoPage()}>Go</button>
      </li>
    </ul>
    <Pagination totalPages={Math.ceil(100 / state.recordsPerPage)} currentPage={state.page} maxVisibleButtons={3} onPageChanged={(e) => onPageChanged(e)} />
  </div>
}

