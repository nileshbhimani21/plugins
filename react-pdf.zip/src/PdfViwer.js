import React, { useState } from 'react';
import pdfFile from './sample.pdf';
import { Document, Page, pdfjs } from 'react-pdf';
import 'react-pdf/dist/esm/Page/AnnotationLayer.css';
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;

export const PdfViwer = () => {
    const [numPages, setNumPages] = useState(null);
    const [pageNumber, setPageNumber] = useState(1);
    const [scale, setScale] = useState(1);

    function onDocumentLoadSuccess({ numPages }) {
        setNumPages(numPages);
    }
    return (
        <div>
            <Document
                file={pdfFile}
                onLoadSuccess={onDocumentLoadSuccess}
            >
                <Page pageNumber={pageNumber} width={900} scale={scale} />
            </Document>
            <p>Page {pageNumber} of {numPages}</p>
            <button onClick={() => setScale(scale - 0.1)}>
                Zoom Out
            </button>
            <button onClick={() => setScale(scale + 0.1)}>
                Zoom In
            </button>
            <button onClick={() => setPageNumber(pageNumber - 1)}>
                Prev page
            </button>
            <button onClick={() => setPageNumber(pageNumber + 1)}>
                Next page
            </button>
        </div>
    );
}
