import React from 'react';
import { PdfViwer } from './PdfViwer';

function App() {
  return (<>
    <PdfViwer />
  </>);
}
export default App