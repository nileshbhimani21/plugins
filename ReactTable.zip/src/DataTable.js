import React, { useEffect } from "react";
//Datatable Modules
import "datatables.net/js/jquery.dataTables";
import "datatables.net-bs4/js/dataTables.bootstrap4";
import "datatables.net-responsive/js/dataTables.responsive";
import * as $ from "jquery";

export const DataTable = (props) => {
  useEffect(() => {
    $("#DataTables").DataTable({
      data: props.TableBody,
      columns: props.TableHeader,
    });
  });
  return (
    <>
      <table
        id="DataTables"
        className="table dt-responsive nowrap w-100"
      ></table>
    </>
  );
};
