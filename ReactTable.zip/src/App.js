import React from "react";
import { Container } from "react-bootstrap";
import { DataTable } from "./DataTable";
import view from "./images/eye.svg";
import edit from "./images/Write.svg";
import Delete from "./images/Trash.svg";

var TableHeader = [
  {
    title: "Name",
    data: "Name",
  },
  {
    title: "Position",
    data: "Position",
  },
  {
    title: "Office",
    data: "Office",
  },
  {
    title: "Salary",
    data: "Salary",
  },
  {
    title: "Action",
    data: "Action",
  },
];
var TableBody = [
  {
    id: "1",
    Name: "Jena Gaines",
    Position: "Sales Assistant",
    Office: "Edinburgh",
    Salary: "$1,200,000",
    Action: `<button type="button" class="btn btn-icon btn-success btn-sm mx-3"><img src="${view}" alt="view" width="15px"/></button><button type="button" class="btn btn-icon btn-primary btn-sm mx-3"><img src="${edit}" alt="edit" width="15px"/></button><button type="button" class="btn btn-icon btn-danger btn-sm mx-3"><img src="${Delete}" alt="Delete" width="15px"/></button>`,
  },
  {
    id: "2",
    Name: "Brenden Wagner",
    Position: "Software Engineer",
    Office: "San Francisco",
    Salary: "$206,850",
    Action: `<button type="button" class="btn btn-icon btn-success btn-sm mx-3"><img src="${view}" alt="view" width="15px"/><button type="button" class="btn btn-icon btn-primary btn-sm mx-3"><img src="${edit}" alt="edit" width="15px"/></button><button type="button" class="btn btn-icon btn-danger btn-sm mx-3"><img src="${Delete}" alt="Delete" width="15px"/></button>`,
  },
  {
    id: "1",
    Name: "Ena Gaines",
    Position: "Pre-Sales Support",
    Office: "Edinburgh",
    Salary: "$100,000",
    Action: `<button type="button" class="btn btn-icon btn-success btn-sm mx-3"><img src="${view}" alt="view" width="15px"/><button type="button" class="btn btn-icon btn-primary btn-sm mx-3"><img src="${edit}" alt="edit" width="15px"/></button><button type="button" class="btn btn-icon btn-danger btn-sm mx-3"><img src="${Delete}" alt="Delete" width="15px"/></button>`,
  },
];
const App = () => {
  return (
    <>
      <Container className="pt-5">
        <DataTable TableHeader={TableHeader} TableBody={TableBody} />
      </Container>
    </>
  );
};

export default App;
