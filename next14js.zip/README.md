## Next 14

Install dependencies

```bash
npm install
```

Start the server

```bash
npm run dev
```

Now you can visit https://localhost:3000 in your browser.
