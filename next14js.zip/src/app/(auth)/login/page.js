import React from "react";
import { Login } from "@/components/auth/login";

const login = () => {
  return <Login />;
};

export default login;
