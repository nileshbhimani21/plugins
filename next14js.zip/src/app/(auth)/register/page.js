import React from "react";
import { Register } from "@/components/auth/register";

const register = () => {
  return <Register />;
};

export default register;
