import { AccountsPage } from "@components/accounts";

const Accounts = () => {
  return <AccountsPage />;
};

export default Accounts;
