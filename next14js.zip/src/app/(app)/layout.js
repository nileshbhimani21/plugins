import { Layout } from "@/components/layout/layout";
import "@/styles/globals.css";

export default function RootLayout({ children }) {
  return <Layout>{children}</Layout>;
}
