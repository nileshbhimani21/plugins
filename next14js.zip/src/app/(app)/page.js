import { Content } from "@/components/home/content";

const Home = () => {
  return <Content />;
};

export default Home;
