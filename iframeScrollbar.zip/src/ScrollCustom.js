import React, { useEffect, useRef, useState } from 'react'


const ScrollCustom = () => {
    const [screenshotHeight, setScreenshotHeight] = useState(0)
    const imgElement = useRef(null)
    const divElement = useRef(null)
    let YValue = 1500
    const handleDivScroll = () => {
        document.getElementsByClassName('target')[0].style.top = `${(YValue * 100) / screenshotHeight}%`
        const scrollPosition = divElement.current.scrollTop
        document.getElementsByClassName('targetScroll')[0].style.top = `${(scrollPosition * 100) / screenshotHeight}%`
        const firstHeight = screenshotHeight / divElement.current.clientHeight
        document.getElementsByClassName('targetScroll')[0].style.height = `${100 / firstHeight}%`


    }
    useEffect(() => {
        handleDivScroll()
        if (divElement) {
            divElement.current.scrollTo(0, YValue)
        }
    })

    return (<>
        <div className="scrollbar">
            <div className="target"></div>
            <div className="targetScroll"></div>
        </div>
        <div onScroll={handleDivScroll} ref={divElement} style={{ height: 500, overflowY: 'auto', scrollBehavior: 'smooth' }}>
            <img src={'https://test-cos-trailit.s3.fra.eu.cloud-object-storage.appdomain.cloud/1638530864105_youtube.png'} alt='' ref={imgElement}
                onLoad={() => {
                    setScreenshotHeight(imgElement.current.height)
                }} />
        </div>
    </>);
}
export default ScrollCustom;