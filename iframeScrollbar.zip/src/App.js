import React from 'react';
import ScrollCustom from './ScrollCustom';

const App = () => {
  return (<>
    <ScrollCustom />
  </>);
}
export default App;
