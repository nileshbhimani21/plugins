/* eslint-disable jsx-a11y/label-has-associated-control */
// eslint-disable-next-line quotes
module.exports = { extends: ["@commitlint/config-angular"] };
