import React from 'react'
import {Slider, Rail, Handles, Tracks} from 'react-compound-slider'
import {SliderRail, Handle, Track} from './RangeSlider' // example render components - source below

const sliderStyle = {
  position: 'relative',
  width: '100%',
}

const RSlider = props => {
  const {mode, step, domain, defaultValues, left, handleUpdateRange, handleChangeRange} = props
  return (
    <div>
      <Slider
        mode={mode}
        step={step}
        domain={domain}
        rootStyle={sliderStyle}
        onUpdate={values => handleUpdateRange(values)}
        onChange={values => handleChangeRange(values)}
        values={defaultValues}
        reversed={false}
      >
        <Rail>{({getRailProps}) => <SliderRail getRailProps={getRailProps} />}</Rail>
        <Handles>
          {({handles, getHandleProps}) => (
            <div className="slider-handles">
              {handles.map(handle => (
                <Handle
                  key={handle.id}
                  handle={handle}
                  domain={props.domain}
                  getHandleProps={getHandleProps}
                  valueTooltip={props.valueTooltip}
                />
              ))}
            </div>
          )}
        </Handles>
        <Tracks left={left} right={false}>
          {({tracks, getTrackProps}) => (
            <div className="slider-tracks">
              {tracks.map(({id, source, target}) => (
                <Track key={id} source={source} target={target} getTrackProps={getTrackProps} />
              ))}
            </div>
          )}
        </Tracks>
      </Slider>
    </div>
  )
}
export default RSlider
