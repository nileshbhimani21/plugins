import React, { useState, useRef } from 'react';
import workerClient from "ffmpeg-webworker-custom";
import { Button, Container } from 'react-bootstrap';
import { arrayBufferToBlob } from './utils';
import RSlider from './RangeSlider/Slider';

const App = () => {
  const videoFileRef = useRef(null)
  const [VideoFile, setVideoFile] = useState('')
  const [VideoDefautFile, setVideoDefautFile] = useState('')
  const [TrimShow, setTrimShow] = useState(false)
  const [defaultValues, setDefaultValues] = useState([])
  const [domain, setDomain] = useState([])

  // upload file
  const handleInputChange = (e) => {
    const file = e.target.files[0];
    setVideoDefautFile(file)
    const userVideoBlob = URL.createObjectURL(file)
    setVideoFile(userVideoBlob)
    setTimeout(() => {
      setDefaultValues([0, videoFileRef.current.duration])
      setDomain([0, videoFileRef.current.duration])
    }, 1000)
  }
  //trim show
  const handleTrimShow = () => setTrimShow(!TrimShow)

  //trim video set function
  const handleUpdateRangeSlider = v => {
    setDefaultValues(v)
  }
  const handleChangeRangeSlider = v => {
    //setDefaultValues(v)
  }
  //trim video function
  const handleTrimVideo = () => {
    if (VideoDefautFile) {
      workerClient.inputFile = VideoDefautFile;
      workerClient.runCommand(`-ss ${defaultValues[0]} -c copy -t ${defaultValues[1]} ${VideoDefautFile.name}`);
      workerClient.on("onDone", data => {
        console.log(data, 'data')
        let videoBlob = arrayBufferToBlob(data[0].data);
        let videoURL = URL.createObjectURL(videoBlob);
        setVideoFile(videoURL)
        const myFile = new File([videoBlob], VideoDefautFile.name, {
          type: "video/mp4",
        });

        setVideoDefautFile(myFile);
        setTimeout(() => {
          setDefaultValues([0, videoFileRef.current.duration])
          setDomain([0, videoFileRef.current.duration])
        }, 1000)
      });
    }
    setTrimShow(false)
  }

  return (
    <Container className="p-3" >
      <input type="file" accept="audio/*,video/*" onChange={e => handleInputChange(e)} />
      <br />
      <video
        ref={videoFileRef}
        width={300}
        src={VideoFile}
        controls>
      </video>
      <br />

      {TrimShow ? <Button variant="primary" onClick={handleTrimVideo}>Reset</Button> :
        <Button variant="primary" onClick={handleTrimShow}>Trim</Button>}
      {TrimShow && <div className="TL_sliderTrimVideo">
        <RSlider
          handleChangeRange={(e) => handleChangeRangeSlider(e)}
          handleUpdateRange={(e) => handleUpdateRangeSlider(e)}
          domain={domain}
          defaultValues={defaultValues}
          mode={2}
          step={0.01}
          left={false}
        />
      </div>}
    </Container >
  );
}
export default App;
