const jwt = require('jsonwebtoken')
require('dotenv').config();

const TOKEN_EXPIRATION_SEC = '1d';
const VERIFICATION_EXP_SEC = '1h'

const jwtSign = function (userData) {
  const options = { expiresIn: TOKEN_EXPIRATION_SEC };
  const token = jwt.sign(userData, process.env.USER_JWT_KEY, options)
  return token
}
const jwtVarify = function (userData) {
  const options = { expiresIn: VERIFICATION_EXP_SEC };
  const token = jwt.verify(userData, process.env.USER_JWT_KEY, options)
  console.log(token, 'token')
  return token;
}

module.exports = { jwtSign, jwtVarify }