"use strict";

// const { fileContentAppend } = require("../utils/notificationHelper");

//========================== Load Internal Module =========================

//========================== Load Modules End =============================

function hndlError(err, req, res, next) {
    // unhandled error
    sendError(res, err);
}

function sendError(res, err) {
    // if error doesn't has sc than it is an unhandled error,
    // log error, and throw intrnl server error
    if (!err.code) {
        return res.status(500).json({
            code: 500,
            status: false,
            message: "Internal server err",
            data: {}
        })
    }
    return res.status(err.code).json({
        code: err.code,
        status: err.status,
        message: err.message,
        data: err.data

    })
}

function sendSuccess(res, rslt) {
    return res.status(rslt.code).json({
        code: rslt.code,
        status: rslt.status,
        message: rslt.message,
        data: rslt.data
    })
}


/** Request Response 
 * 
 * @param {string} message response message
 *  @param {object} data response Data
 */
function requestResponse(code, status, message, data) {
    var responseObj = {
        "code": code,
        "status": status,
        "message": message,
        "data": data
    }
    return responseObj;
}

//========================== Exposed Action Start ==========================

module.exports = {
    hndlError, sendError, sendSuccess, requestResponse
};

//========================== Exposed Action End ==========================

function _sendResponse(res, rslt) {
    return res.send(rslt);
}
