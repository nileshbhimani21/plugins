const express = require('express')
const connectDB = require('./config/db')
const userRouter = require('./routes/userRoute')
const app = express()
require('dotenv').config();
// Port
const port = process.env.PORT || 5000

// Database Connecttion
const DATABASE_URL = process.env.DATABASE_URL || "mongodb://localhost/userDemo"
connectDB(DATABASE_URL)

// JSON
app.use(express.json())

// Routes
app.use("/api/user", userRouter)

app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`)
})