const express = require('express')
const bcrypt = require('bcrypt')
const { User, validateSignup, validateLogin } = require('../modules/user')
const auth = require('../middleware/auth')
const admin = require('../middleware/admin')
const { AUTH } = require('../constants')
const userRouter = express.Router()

userRouter.post('/signup', async (req, res) => {
  const { error } = validateSignup(req.body)
  if (error) return res.status(400).send(error.details[0].message)
  let user = await User.findOne({ email: req.body.email })
  if (user) return res.status(400).send(AUTH.userAlreadyRegistered)
  user = new User(req.body)
  const salt = await bcrypt.genSalt(10)
  user.password = await bcrypt.hash(user.password, salt)
  const result = await user.save();
  const token = user.generateAuthToken()
  res.header('x-auth-token', token).send(result);
})

userRouter.post('/login', async (req, res) => {
  const { error } = validateLogin(req.body)
  if (error) return res.status(400).send(error.details[0].message)
  let user = await User.findOne({ email: req.body.email })
  if (!user) return res.status(400).send(AUTH.invalidEmailOrPassword)
  const validPassword = await bcrypt.compare(req.body.password, user.password)
  if (!validPassword) return res.status(400).send(AUTH.invalidEmailOrPassword)
  const token = user.generateAuthToken()
  res.header('x-auth-token', token).send({ _id: user._id, name: user.name, email: user.email, token: token })
})

userRouter.get('/profile', [auth, admin], async (req, res) => {
  const user = await User.findById(req.user._id).select('-password')
  res.send(user)
})
userRouter.get('/logout', auth, async (req, res) => {
  res.header('x-auth-token', '').send(AUTH.logoutSuccessfully)
})

module.exports = userRouter