
const mongoose = require('mongoose')

module.exports = function connectDB(DATABASE_URL) {
  mongoose.connect(DATABASE_URL).then(() => console.log("Connected to MongoDB...")).catch((err) => console.log("Not Connected to MongoDB..."))
}