const AUTH = {
    userAlreadyRegistered: "User already registered.",
    invalidEmailOrPassword: "Invalid email or password.",
    logoutSuccessfully: "Logout successfully."
}

module.exports = Object.freeze({
    AUTH,
});