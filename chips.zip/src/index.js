import React from "react";
import ReactDOM from "react-dom";
import Chips from "./Chips";

import "./styles.css";

export const App = () => {
  return (
    <>
      <Chips />
    </>
  );
};

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
