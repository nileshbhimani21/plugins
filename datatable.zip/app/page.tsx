import Dashboard from '../views/Dashboard';

export default function Home() {
  return <Dashboard />
}
