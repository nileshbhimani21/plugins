import { JSXElementConstructor, Key, ReactElement, ReactFragment, ReactPortal } from "react";

const DataTable = ({ cols, data, bordered, hoverable, striped, isDark }: any) => {
  return (
    <div className="table-responsive">
      <table className={`table ${bordered ? 'table-bordered' : 'table-borderless'} ${hoverable && 'table-hover'} ${striped && 'table-striped'} ${isDark && 'table-dark'}`}>
        <thead>
          <tr>
            {cols.map((headerItem: { title: string | number | boolean | ReactElement<any, string | JSXElementConstructor<any>> | ReactFragment | ReactPortal | null | undefined; }, index: Key | null | undefined) => (
              <th key={index}>{headerItem.title}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((item: any, index: Key | null | undefined) => (
            <tr key={index}>
              {cols.map((col: { render: (arg0: any) => string | number | boolean | ReactElement<any, string | JSXElementConstructor<any>> | ReactFragment | ReactPortal | null | undefined; }, key: Key | null | undefined) => (
                <td key={key}>{col.render(item)}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default DataTable;