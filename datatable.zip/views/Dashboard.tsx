'use client'
import DataTable from "../components/DataTable";

export const tableConstants = (handleEdit: any) => {
  return [
    {
      title: 'ID',
      render: (rowData: { id: string | undefined; }) => {
        return <span>{rowData.id}</span>;
      },
    },
    {
      title: 'Name',
      render: (rowData: { name: string | undefined; }) => {
        return <span>{rowData.name}</span>;
      },
    },
    {
      title: 'Username',
      render: (rowData: { username: string | undefined; }) => {
        return <span>{rowData.username}</span>;
      },
    },
    {
      title: 'Email',
      render: (rowData: { email: string | undefined; }) => {
        return <span>{rowData.email}</span>;
      },
    },
    {
      title: 'Phone',
      render: (rowData: { phone: string | undefined; }) => {
        return <span>{rowData.phone}</span>;
      },
    },
    {
      title: 'Website',
      render: (rowData: { website: string | undefined; }) => {
        return <span>{rowData.website}</span>;
      },
    },
    {
      title: 'Action',
      render: (rowData: any) => {
        return <button className='btn btn-warning' onClick={handleEdit(rowData)}>Edit</button>
      },
    },
  ];
};
export const data = [
  {
    "id": 1,
    "name": "Leanne Graham",
    "username": "Bret",
    "email": "Sincere@april.biz",
    "phone": "1-770-736-8031 x56442",
    "website": "hildegard.org",
  },
  {
    "id": 2,
    "name": "Ervin Howell",
    "username": "Antonette",
    "email": "Shanna@melissa.tv",
    "phone": "010-692-6593 x09125",
    "website": "anastasia.net",
  },
  {
    "id": 3,
    "name": "Clementine Bauch",
    "username": "Samantha",
    "email": "Nathan@yesenia.net",
    "phone": "1-463-123-4447",
    "website": "ramiro.info",
  },
  {
    "id": 4,
    "name": "Patricia Lebsack",
    "username": "Karianne",
    "email": "Julianne.OConner@kory.org",
    "phone": "493-170-9623 x156",
    "website": "kale.biz",
  },
  {
    "id": 5,
    "name": "Chelsey Dietrich",
    "username": "Kamren",
    "email": "Lucio_Hettinger@annie.ca",
    "phone": "(254)954-1289",
    "website": "demarco.info",
  }
]
export default function Dashboard() {
  const handleEdit = (item: any) => () => {
    // write your logic
    alert(JSON.stringify(item))
  }
  return (
    <DataTable cols={tableConstants(handleEdit)} data={data} isDark bordered striped hoverable />
  )
}
