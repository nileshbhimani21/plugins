import React from 'react';
import Main from './examples/Main';
import './App.css';

function App() {
  return (
    <Main />
  );
}

export default App;
