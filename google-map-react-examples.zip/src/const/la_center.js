export default [34.0522, -118.2437];
